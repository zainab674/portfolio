
function myFunction1() {
    var x = document.getElementById("educationshow");
    var y = document.getElementById("languageshow");
    var z = document.getElementById("experienceshow");
        x.style.display = "block";
        y.style.display = "none";
        z.style.display = "none";
    
}
function myFunction2() {
    var x = document.getElementById("educationshow");
    var y = document.getElementById("languageshow");
    var z = document.getElementById("experienceshow");
        y.style.display = "block";
        x.style.display = "none";
        z.style.display = "none";
        
    
}
function myFunction3() {
    var x = document.getElementById("educationshow");
    var y = document.getElementById("languageshow");
    var z = document.getElementById("experienceshow");
        z.style.display = "block";
        x.style.display = "none";
        y.style.display = "none";
   
}